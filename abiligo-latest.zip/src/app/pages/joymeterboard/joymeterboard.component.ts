import { Component } from '@angular/core';

@Component({
  selector: 'app-joymeterboard',
  templateUrl: './joymeterboard.component.html',
  styleUrls: ['./joymeterboard.component.scss',]
})
export class JoymeterboardComponent {
  isDropdownOpen: boolean = false;
  isDropdownOpen2: boolean = false;
}
